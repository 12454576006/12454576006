package com.controller;

import com.dao.DepartmentDao;
import com.entity.Department;
import com.service.DepartmentService;
import com.service.Impl.DepartmentServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(urlPatterns = "/showDeptAllNames")
public class showDeptController extends HttpServlet {
    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //调用业务层方法
        DepartmentService departmentService = new DepartmentServiceImpl();
        List<Department> deps=departmentService.selectAllNames();
        //将数据存在作用域中
        request.setAttribute("deps",deps);
        //调转注册页面
        request.getRequestDispatcher("/Regist.jsp").forward(request,response);
    }
}
