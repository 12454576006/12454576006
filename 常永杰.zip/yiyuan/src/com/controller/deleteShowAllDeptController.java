package com.controller;

import com.service.DepartmentService;
import com.service.Impl.DepartmentServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(urlPatterns = "/user/deleteShowAll")
public class deleteShowAllDeptController extends HttpServlet {
    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String[] ids = req.getParameterValues("ids");
        DepartmentService departmentService=new DepartmentServiceImpl();
        for (String strId : ids) {
            int id = Integer.parseInt(strId);
            departmentService.delete(id);
        }
        resp.sendRedirect(req.getContextPath()+"/user/showAllController");
    }
}
