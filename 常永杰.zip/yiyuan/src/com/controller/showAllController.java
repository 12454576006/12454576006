package com.controller;

import com.entity.Department;
import com.entity.User;
import com.service.DepartmentService;
import com.service.Impl.DepartmentServiceImpl;
import com.service.Impl.USerServiceImpl;
import com.service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet(urlPatterns = "/user/showAllController")
public class showAllController extends HttpServlet {
    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //调用业务层方法
        DepartmentService departmentService = new DepartmentServiceImpl();
        List<Department> deps=departmentService.selectShowAll();
        //将数据存在作用域中
        request.setAttribute("users",deps);
        //跳转页面
        request.getRequestDispatcher("/manager/department/DepartmentList.jsp").forward(request,response);
    }
}
