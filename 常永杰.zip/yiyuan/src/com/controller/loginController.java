package com.controller;

import com.service.Impl.USerServiceImpl;
import com.service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(urlPatterns = "/login")
public class loginController extends HttpServlet {
    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("+++++++++++");
        //获取参数
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        //调用业务层方法
        UserService userService=new USerServiceImpl();
        boolean b=userService.login(username,password);
        if(b){
            //在作用域中标记
            request.getSession().setAttribute("name",username);
            //登录成功
            response.sendRedirect(request.getContextPath() + "/user/showAllController");
            System.out.println("==========");
        }else {
            //登录失败
            response.sendRedirect(request.getContextPath() +"/index.jsp");
        }
    }
}
