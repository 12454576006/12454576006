package com.controller;

import com.entity.Department;
import com.service.DepartmentService;
import com.service.Impl.DepartmentServiceImpl;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(urlPatterns = "/user/updateController")
public class updateDeptController extends HttpServlet {
    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("1111111111111");
        //接受参数
        String Sid = request.getParameter("id");
        int id=Integer.parseInt(Sid);
        String name = request.getParameter("name");
        String telephone = request.getParameter("telephone");
        String area = request.getParameter("area");

        System.out.println("area = " + area);
        //调用业务层方法
        DepartmentService departmentService = new DepartmentServiceImpl();
        departmentService.update(new Department(id,name,telephone,area));
        //调转页面
        response.sendRedirect(request.getContextPath()+"/user/showAllController");
    }
}
