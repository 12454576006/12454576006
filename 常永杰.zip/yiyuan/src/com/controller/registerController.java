package com.controller;

import com.entity.User;
import com.service.Impl.USerServiceImpl;
import com.service.UserService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet(urlPatterns = "/register")
public class registerController extends HttpServlet {
    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //接受参数
        String username = request.getParameter("username");
        String password = request.getParameter("password");
        String realname = request.getParameter("realname");
        String SSex = request.getParameter("sex");
        int sex=Integer.parseInt(SSex);
        String birth = request.getParameter("birth");
        String mobile = request.getParameter("mobile");
        String email = request.getParameter("email");
        String address = request.getParameter("address");
        String SDept_id = request.getParameter("dept_id");
        int dep_id=Integer.parseInt(SDept_id);
        //调用业务层方法
        UserService userService=new USerServiceImpl();
        userService.register(new User(null,username,password,realname,sex,birth,mobile,email,address,dep_id));
        //跳转
        response.sendRedirect(request.getContextPath()+"/user/showAllController");
    }
}
