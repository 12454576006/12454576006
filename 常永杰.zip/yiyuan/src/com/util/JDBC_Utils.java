package com.util;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.Properties;

//JDBCUtils������
public class JDBC_Utils {
    static Properties p = new Properties();
    static ThreadLocal<Connection> tl = new ThreadLocal<>();
    static{
        InputStream is =  null;
        try {
            is = JDBC_Utils.class.getResourceAsStream("/db.properties");
            p.load(is);
        } catch (IOException e) {
            e.printStackTrace();
        }finally {
            if(is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    //�������ӵĺ���
    public static Connection getConn(){
        //��ȡ���Ӷ���
        Connection conn = tl.get();
        //�����ȡ����  �����û�д���Connection
        if(conn == null){
            try{
                Class.forName(p.getProperty("driver"));
                conn = DriverManager.getConnection(p.getProperty("url"),p.getProperty("username"),p.getProperty("password"));
                //��conn������ThreadLocal
                tl.set(conn);
            }catch(Exception e){
                e.printStackTrace();
                throw new RuntimeException(e);
            }
        }
        return conn;
    }

    //�ͷ���Դ�ĺ���
    public static void close(Connection conn, PreparedStatement pstmt, ResultSet rs){
        if(rs != null)try{rs.close();}catch(Exception e){e.printStackTrace();throw new RuntimeException(e);}
        if(pstmt != null)try{pstmt.close();}catch(Exception e){e.printStackTrace();throw new RuntimeException(e);}
        if(conn != null)try{conn.close();tl.remove();}catch(Exception e){e.printStackTrace();throw new RuntimeException(e);}
    }

    public static void main(String[] args) {
        Connection conn = JDBC_Utils.getConn();
        System.out.println("conn = " + conn);
    }
}
