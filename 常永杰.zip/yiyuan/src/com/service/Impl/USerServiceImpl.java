package com.service.Impl;

import com.dao.Impl.UserDaoImpl;
import com.dao.UserDao;
import com.entity.User;
import com.service.UserService;
import com.util.JDBC_Utils;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

public class USerServiceImpl implements UserService {
    @Override
    public boolean login(String username, String password) {
        UserDao userDao=new UserDaoImpl();
        return userDao.selectUserByUsernameAndPassword(username,password);
    }

    @Override
    public void register(User user) {
        UserDao userDao=new UserDaoImpl();
        Connection conn = null;
        try {
            conn = JDBC_Utils.getConn();
            //开启事务
            conn.setAutoCommit(false);
            //调用dao方法
            userDao.insertUser(user);
            //提交事务
            conn.commit();
        } catch (Exception e) {
            e.printStackTrace();
            try {
                conn.rollback();
            } catch (Exception e1) {
                e1.printStackTrace();
            }
        } finally {
            JDBC_Utils.close(conn, null, null);
        }
    }

    @Override
    public List<User> queryAllPerson() {
        UserDao userDao=new UserDaoImpl();
        return userDao.selectShowAllUser();
    }
}
