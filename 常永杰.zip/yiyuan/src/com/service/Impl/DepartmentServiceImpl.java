package com.service.Impl;

import com.dao.DepartmentDao;
import com.dao.Impl.DepartmentImpl;
import com.entity.Department;
import com.service.DepartmentService;
import com.util.JDBC_Utils;

import java.sql.Connection;
import java.util.List;

public class DepartmentServiceImpl implements DepartmentService {
    @Override
    public List<Department> selectAllNames() {
        DepartmentDao departmentDao=new DepartmentImpl();
        return departmentDao.selectDepartmentNames();
    }

    @Override
    public List<Department> selectShowAll() {
        DepartmentDao departmentDao=new DepartmentImpl();
        return departmentDao.selectDepartmentShowAll();
    }

    @Override
    public void delete(int id) {
        Connection conn=null;
        try{
            conn = JDBC_Utils.getConn();
            //开启手动控制事务
            conn.setAutoCommit(false);

            //调dao方法完成功能
            DepartmentDao departmentDao=new DepartmentImpl();
            departmentDao.deleteDepartment(id);

            //没有问题
            conn.commit();
        }catch (Exception e){
            e.printStackTrace();
            //回滚事务
            try{
                conn.rollback();
            }catch (Exception e1){
                e1.printStackTrace();
            }
        }finally{
            JDBC_Utils.close(conn,null,null);
        }
    }

    @Override
    public void update(Department department) {
        Connection conn = null;
        try{
            conn = JDBC_Utils.getConn();
            //开启手动控制事务
            conn.setAutoCommit(false);
            //调dao方法完成功能
            DepartmentDao departmentDao=new DepartmentImpl();
            departmentDao.updateDept(department);
            //回滚事务
            conn.commit();
        }catch (Exception e){
            e.printStackTrace();
            //回滚事务
            try{
                conn.rollback();
            }catch (Exception e1){
                e1.printStackTrace();
            }
        }finally{
            JDBC_Utils.close(conn,null,null);
        }
    }

    @Override
    public void insert(Department department) {
        Connection conn = null;
        try{
            conn = JDBC_Utils.getConn();
            //开启手动控制事务
            conn.setAutoCommit(false);
            //调dao方法完成功能
            DepartmentDao departmentDao=new DepartmentImpl();
            departmentDao.insertDept(department);
            //回滚事务
            conn.commit();
        }catch (Exception e){
            e.printStackTrace();
            //回滚事务
            try{
                conn.rollback();
            }catch (Exception e1){
                e1.printStackTrace();
            }
        }finally{
            JDBC_Utils.close(conn,null,null);
        }
    }
}
