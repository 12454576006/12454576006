package com.service;

import com.entity.Department;

import java.util.List;

public interface DepartmentService {
    //根据id查
    List<Department> selectAllNames();
    //查所有
    List<Department> selectShowAll();
    //删除
    void delete(int id);
    //修改
    void update(Department department);
    //添加
    void insert(Department department);
}
