package com.service;

import com.entity.User;

import java.util.List;

public interface UserService {
    //登录
    boolean login(String username,String password);
    //注册
    void register(User user);
    //查询所有
    List<User> queryAllPerson ();
}
