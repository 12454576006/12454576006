package com.test;

import com.entity.User;
import com.service.Impl.USerServiceImpl;
import com.service.UserService;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;

public class testUser {
    @Test
    public void testLogin(){
        UserService userService=new USerServiceImpl();
        boolean b=userService.login("cyj","123456");
        if(b){
            System.out.println("登录成功");
        }else {
            System.out.println("用户名或密码错误");
        }
    }
    @Test
    public void testRegister(){
        UserService userService=new USerServiceImpl();
        userService.register(new User(null,"cyj","123456","常永杰",1,"2002-07-31","13403908012","1254576006@qq.com","河南省孟州市",1));
    }
    @Test
    public void testQueryAllPerson(){
        UserService userService=new USerServiceImpl();
        List<User> list=userService.queryAllPerson();
        list.forEach(System.out::println);
    }
}
