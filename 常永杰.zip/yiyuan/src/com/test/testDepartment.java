package com.test;

import com.entity.Department;
import com.service.DepartmentService;
import com.service.Impl.DepartmentServiceImpl;
import org.junit.Test;

import java.util.List;

public class testDepartment {
    @Test
    public void testSelectAllNames(){
        DepartmentService departmentService=new DepartmentServiceImpl();
        List<Department> list=departmentService.selectAllNames();
        list.forEach(System.out::println);
    }
   @Test
    public void testSelectShowAll(){
       DepartmentService departmentService = new DepartmentServiceImpl();
       List<Department> list=departmentService.selectShowAll();
       list.forEach(System.out::println);
   }
   @Test
    public void testDelete(){
        DepartmentService departmentService=new DepartmentServiceImpl();
        departmentService.delete(3);
   }
   @Test
    public void testUpdate(){
        DepartmentService departmentService=new DepartmentServiceImpl();
        departmentService.update(new Department(2,"内科","11111","三楼C区"));
   }
   @Test
    public void testInsert(){
        DepartmentService departmentService=new DepartmentServiceImpl();
        departmentService.insert(new Department(null,"肛肠科","8266666","四楼A区"));
   }
}
