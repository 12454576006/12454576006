package com.dao;

import com.entity.Department;

import java.util.List;

public interface DepartmentDao {
    //根据id查科室
    List<Department> selectDepartmentNames();
    //查询所有
    List<Department> selectDepartmentShowAll();
    //删除
    void deleteDepartment(int id);
    //修改
    void updateDept(Department department);
    //添加
    void insertDept(Department department);
}
