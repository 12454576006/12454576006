package com.dao;

import com.entity.User;

import java.util.List;

public interface UserDao {
    //登录
    boolean selectUserByUsernameAndPassword(String username ,String password );
    //增加
    void insertUser(User user);
    //查询
    List<User> selectShowAllUser();
}
