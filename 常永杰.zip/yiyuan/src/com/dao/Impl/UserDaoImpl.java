package com.dao.Impl;

import com.dao.UserDao;
import com.entity.User;
import com.util.JDBC_Utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class UserDaoImpl implements UserDao {
    //根据用户名和密码登录
    @Override
    public boolean selectUserByUsernameAndPassword(String username, String password) {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;

        try{
            conn = JDBC_Utils.getConn();

            String sql = "select * from t_user where username = ? and password = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1,username);
            pstmt.setString(2,password);

            rs = pstmt.executeQuery();

            if(rs.next()){//如果rs.next()返回true  则代表数据库中存在数据
                return true;
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally{
            JDBC_Utils.close(conn,pstmt,rs);
        }
        return false;
    }
    //添加
    @Override
    public void insertUser(User user) {
        Connection conn=null;
        PreparedStatement pstmt=null;
        try {
            //创建连接
            conn=JDBC_Utils.getConn();
            //创建 PreparedStatement
            String sql="insert into t_user values(null,?,?,?,?,?,?,?,?,?)";
            pstmt=conn.prepareStatement(sql);
            //为？ 赋值
            pstmt.setString(1, user.getUsername());
            pstmt.setString(2, user.getPassword());
            pstmt.setString(3,user.getRealname());
            pstmt.setInt(4,user.getSex());
            pstmt.setString(5,user.getBirth());
            pstmt.setString(6,user.getMobile());
            pstmt.setString(7,user.getEmail());
            pstmt.setString(8, user.getAddress());
            pstmt.setInt(9,user.getDept_id());
            //执行sql
            pstmt.executeUpdate();

        }catch (Exception e){
            e.printStackTrace();
        }finally {
            JDBC_Utils.close(null,pstmt,null);
        }

    }

    @Override
    public List<User> selectShowAllUser() {
        Connection conn = null;
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        List<User> list = new ArrayList<>();
        try {
            conn = JDBC_Utils.getConn();
            String sql = "select * from t_user";
            pstmt = conn.prepareStatement(sql);
            rs = pstmt.executeQuery();
            while (rs.next()){
                int id = rs.getInt("id");
                String username = rs.getString("username");
                String password = rs.getString("password");
                String realname = rs.getString("realname");
                int sex = rs.getInt("sex");
                String birth = rs.getString("birth");
                String mobile = rs.getString("mobile");
                String email = rs.getString("email");
                String address = rs.getString("address");
                int dept_id = rs.getInt("dept_id");

                User user=new User(id,username,password,realname,sex,birth,mobile,email,address,dept_id);
                list.add(user);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }finally {
            JDBC_Utils.close(conn,pstmt,rs);
        }
        return list;
    }
}
