package com.dao.Impl;

import com.dao.DepartmentDao;
import com.entity.Department;
import com.util.JDBC_Utils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class DepartmentImpl implements DepartmentDao {
    @Override
    public List<Department> selectDepartmentNames() {
        Connection conn=null;
        PreparedStatement pstmt=null;
        ResultSet rs=null;
        List<Department> depd=new ArrayList<>();
        try {
            conn=JDBC_Utils.getConn();
            String sql="select id,name from t_department";
            pstmt=conn.prepareStatement(sql);
            rs=pstmt.executeQuery();
            while (rs.next()){
                int id = rs.getInt("id");
                String name = rs.getString("name");
                Department department=new Department();
                department.setId(id);
                department.setName(name);
                depd.add(department);
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            JDBC_Utils.close(conn,pstmt,rs);
        }
        return depd;
    }

    @Override
    public List<Department> selectDepartmentShowAll() {
        Connection conn=null;
        PreparedStatement pstmt=null;
        ResultSet rs=null;
        List<Department> depd=new ArrayList<>();
        try {
            conn=JDBC_Utils.getConn();
            String sql="select * from t_department";
            pstmt=conn.prepareStatement(sql);
            rs=pstmt.executeQuery();
            while (rs.next()){
                int id = rs.getInt("id");
                String name = rs.getString("name");
                String telephone = rs.getString("telephone");
                String area = rs.getString("area");
                Department department=new Department(id,name,telephone,area);

                depd.add(department);
            }
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            JDBC_Utils.close(conn,pstmt,rs);
        }
        return depd;
    }

    @Override
    public void deleteDepartment(int id) {
        Connection conn=null;
        PreparedStatement pstmt=null;
        try {
            //创建连接
            conn=JDBC_Utils.getConn();
            //创建
            String sql="delete from t_department where id= ?";
            pstmt=conn.prepareStatement(sql);
            //为？赋值
            pstmt.setInt(1,id);
            //执行sql
            pstmt.executeUpdate();
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            JDBC_Utils.close(null,pstmt,null);
        }
    }

    @Override
    public void updateDept(Department department) {
        Connection conn=null;
        PreparedStatement pstmt= null;
        try {
            //创建连接
            conn = JDBC_Utils.getConn();
            //创建PreparedStatement
            String sql = "update t_department set name =?,telephone=?,area=? where id = ?";
            pstmt = conn.prepareStatement(sql);
            //为？赋值
            pstmt.setString(1,department.getName());
            pstmt.setString(2,department.getTelephone());
            pstmt.setString(3,department.getArea());
            pstmt.setInt(4,department.getId());
            //执行sql
            pstmt.executeUpdate();
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            JDBC_Utils.close(null,pstmt,null);
        }
    }

    @Override
    public void insertDept(Department department) {
        Connection conn=null;
        PreparedStatement pstme=null;
        try {
            //创建连接
            conn= JDBC_Utils.getConn();
            //创建PreparedStatement
            String sql ="insert into t_department values(null,?,?,?)";
            pstme=conn.prepareStatement(sql);
            //为？赋值
            pstme.setString(1,department.getName());
            pstme.setString(2,department.getTelephone());
            pstme.setString(3,department.getArea());
            //执行sql
            pstme.executeUpdate();
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            JDBC_Utils.close(null,pstme,null);
        }
    }
}
